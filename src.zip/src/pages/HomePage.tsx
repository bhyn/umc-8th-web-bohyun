
const HomePage = () => {
    return (
        <div className='h-dvh flex flex-col'>
            <h1>    홈페이지</h1>
        </div>
    );
};

export default HomePage;