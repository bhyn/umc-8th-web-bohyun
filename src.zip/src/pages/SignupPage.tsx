const SignupPage = () => {
  return (
    <div>
        <h1>Signup Page</h1>
      {/* Add your signup form here */}
    </div>
  );
}

export default SignupPage;